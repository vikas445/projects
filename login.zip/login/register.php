<html>
	<title>register page</title>
		<head>
			
		
			<style>
			*{
			  margin: 5;
			  padding: 0;
			  font-family: Century Gothic;
			}

			header {
				background-image: uri("violet.png"); 
				height: 100vh;
				background-size: cover;
				background-position: center; 
			}

			ul{
			  float:right;
			  list-style-type: none:
			}

			ul li{
			  display: inline-block;
			}

			ul li a {
			  text-decoration: none;
			  color: #fff;
			  padding: 5px 20px;
			  border: 1px solid #fff;
			  transition: 0.6s ease;
			}

			.title {
			  position: absolute;
			  top: 25%;
			  left: 50%;
			  transform: translate(-50%,-50%);
			  color: #fff;
			}



			.button{
			  position: absolute;
			  top: 50%;
			  left: 50%;
			  transform: translate(-50%,-50%);
			}

			.btn{
			  text-decoration: none;
			  color: #fff;
			  padding: 10px 90px;
			  border: 1px solid #fff;
			  transition: 0.6s ease;
			}

			 a:hover{
			  background-color: #fff;
			  color:#000; 
			}



			.logo img {
			float: left;
			width: 150px;
			height: auto;
			}

			.login-page {
			  width:500px;
			  padding: 8% 0 0;
			  margin: auto;
			}
			.form {
			  position: relative;
			  z-index: 1;
			  background: #FFFFFF;
			  max-width: 500px;
			  margin: 0 auto 100px;
			  padding: 45px;
			  text-align: center;
			  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
			}
			.form input {
			  font-family: "Roboto", sans-serif;
			  outline: 0;
			  background: #f2f2f2;
			  width: 100%;
			  border: 0;
			  margin: 0 0 15px;
			  padding: 15px;
			  box-sizing: border-box;
			  font-size: 14px;
			}
			.form button {
			  font-family: "Roboto", sans-serif;
			  text-transform: uppercase;
			  outline: 0;
			  background: #3498db;
			  width: 100%;
			  border: 0;
			  padding: 15px;
			  color: #FFFFFF;
			  font-size: 14px;
			  -webkit-transition: all 0.3 ease;
			  transition: all 0.3 ease;
			  cursor: pointer;
			}
			.form button:hover,.form button:active,.form button:focus {
			  background: #2161bc;
			}
			.form .message {
			  margin: 15px 0 0;
			  color: #b3b3b3;
			  font-size: 12px;
			}
			.form .message a {
			  color: #3498db;
			  text-decoration: none;
			}
			.form .register-form {
			  display: none;
			}
			body {
			  background:url("images/Indian-railway.jpg") no-repeat center;
			  background-size: cover;
			  height:100vh;
			  background-attachment:fixed;
			}
     </style>
		</head>
	<body>
	<div class="main">
			<ul>
				<li><a href="home.php">Home</a></li>
				<li><a href="feedback.php">feedback</a></li>
				<li><a href="aboutus.php">About us</a></li>
			</ul>
		</div>
		<br><br>
	<h1 style="font-size:30px;color:white;top:15%;left:45%;position:absolute;">Register</h1>
		<div class="login-page">
			<div class="form">
				<form class="login-form" action="registerprocess.php" method="post">
					<input type="text" name="firstname" required placeholder="Enter First Name"/>
					<input type="text" name="lastname" required placeholder="Enter Last Name"/>
					<input type="text" name="username" required placeholder="Username"/>
					<input type="password" name="password" required placeholder="password"/>
					<input type="password" name="password2" required placeholder="re-enter password"/>
					<input type="email" name="email" required placeholder="email address"/>
					<input type="text" name="address" required placeholder="address"/>
					<input type="text" name="dob" class="textbox-n" required placeholder="Date of Birth" onfocus="(this.type='date')" id="date" />
					<input type="text" name="mobno" required placeholder="mobile number"/>
					<input type="text" name="state" required placeholder="state"/>
					<button name="register_btn" >create</button>
					<p class="message">Already registered? <a href="login.php">Sign In</a></p>
				</form>
			</div>
		</div>
	</body>
<html>



