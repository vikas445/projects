<html>
	<head>
		<title>PNR</title>
		<link rel="stylesheet" type="text/css" href="style.css">
		
		
		
	</head>
	<body>
	
		
		
		<div class="title">
			<h1>View Ticket Detail</h1>
		</div>
		<div class="main">
			<ul>
				<li><a href="welcome.php">Main Page</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</div>
		
		<div class="login-page1">
		<div class ="form1">
		<form class="login-form1" action="pnrprocess.php" method="post">
			<table  border="1">
			
				<tr>
					<td>
						<p style="margin-left:10px;">Enter pnr number :</p>
					</td>
					<td>
						<input type="text" name="pnr" style="margin-left:40px;padding:20;top:10">
					</td>
				</tr>
				
				
			</table>
			<button name="view">View detail</button>
			<input type = "reset" value = "reset">
			
		</form>
				</div>
				</div>
	</body>
</html>