<html>
	<head>
		<title>welcome</title>
		<link rel="stylesheet" type="text/css" href="style.css">
		
		
		
	</head>
	<body>
	
		
		<div class="title">
			<h1>cancel your ticket</h1>
		</div>
		
		<div class="main">
			<ul>
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</div>
		
		<div class="login-page1">
		<div class ="form1">
		<form class="login-form1" action="bookingcancelprocess.php" method="post">
			<table  border="1">
			
				<tr>
					<td>
						<p style="margin-left:10px;">Enter pnr number :</p>
					</td>
					<td>
						<input type="text" name="pnr" style="margin-left:40px;padding:20;top:10">
					</td>
				</tr>
				
				
			</table>
			<button name="cancel">Submit</button>
			<input type = "reset" value = "reset">
			
		</form>
				</div>
				</div>
	</body>
</html>