<?php
	$pnr=$_POST['pnr'];

	$db=mysqli_connect("localhost","root","","login");
	
	if(isset($_POST['cancel']))
	{
		$result=mysqli_query($db,"SELECT * FROM booked_passenger where pnr='$pnr'");
		if($result)
		{
			$sql=mysqli_query($db,"DELETE FROM booked_passenger WHERE pnr='$pnr'");
			mysqli_query($db,$sql);
			echo "<script>alert('account deleted sucessfully');</script>";
			echo "<script>location.href='welcome.php'</script>";
		}
		else
		{
			echo "<script>alert('please check pnr number!');</script>";
		}
	}
	
	
?>