<html>
<head>
	<title>booked ticket</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>


		<div class="main">
			<ul>
				<li><a href="welcome.php">Main Page</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</div>

<h1 style="font-size:30px;color:white;top:30%;left:40%;position:absolute;">User Details</h1>
	<div id = "printarea">
<?php
	
	session_start();
	$u=$_SESSION["loginuser"];
	$c=mysqli_connect("localhost","root","","login");
	$result=mysqli_query($c,"SELECT * FROM register where username='$u'");
	$row = mysqli_fetch_array($result);

	
	echo "<table height=100 width=900 border='1' bgcolor='#ffffcc' style='font-size:15px;color:black;padding:10px;top:50%;left:10%;position:absolute;'''>
			<tr>
				<td><center>First Name</center></td>
				<td><center>".$row['firstname']."</center></td>
			</tr>
			<tr>
				<td><center>Last Name</center></td>
				<td><center>".$row['lastname']."</center></td>
			</tr>
			<tr>
				<td><center>Username</center></td>
				<td><center>".$row['username']."</center></td>
			</tr>
			<tr>
				<td><center>Password</center></td>
				<td><center>".$row['password']."</center></td>
			</tr>
			<tr>
				<td><center>Email address</center></td>
				<td><center>".$row['email']."</center></td>
			</tr>
			<tr>
				<td><center>First Name</center></td>
				<td><center>".$row['address']."</center></td>
			</tr>
			<tr>
				<td><center>Date of Birth</center></td>
				<td><center>".$row['dob']."</center></td>
			</tr>
			<tr>
				<td><center>Mobile no.</center></td>
				<td><center>".$row['mobno']."</center></td>
			</tr>
			<tr>
				<td><center>State</center></td>
				<td><center>".$row['state']."</center></td>
			</tr>
			</table>
			" ;
	
	
	
?>

	
</div>

<input type="button" onclick="printDiv('printarea')" value="print it"/>



</body>
</html>
