<html>
<head>
	<title>booked ticket</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<script type="text/javascript">
		function printDiv(divName) 
		{ 
			var printContents = document.getElementById(divName).innerHTML;
		 	var originalContents = document.body.innerHTML;
		  	document.body.innerHTML = printContents;
		   	window.print(); document.body.innerHTML = originalContents;
		}
	</script>
</head>
<body>


		<div class="main">
			<ul>
				<li><a href="welcome.php">Main Page</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</div>

<h1 style="font-size:30px;color:white;top:30%;left:35%;position:absolute;">Your Ticket Details as follow</h1>
	<div id = "printarea">
<?php
	$pnr=$_POST['pnr'];
session_start();
	$c=mysqli_connect("localhost","root","","login");
	$result=mysqli_query($c,"SELECT * FROM booked_passenger where pnr='$pnr'");
	$row = mysqli_fetch_array($result);

	
	echo "<table height=100 width=900 border='1' bgcolor='#ffffcc' style='font-size:15px;color:black;padding:10px;top:50%;left:10%;position:absolute;'''>
			<tr>
				<td><center>pnr</center></td>
				<td><center>Express</center></td>
				<td><center>Source Station</center></td>
				<td><center>Destination station</center></td>
				<td><center>Date</center></td>
				<td><center>Class</center></td>
				<td><center>No. of Adults</center></td>
				<td><center>No. of Childrens</center></td>
			</tr>
			<tr>
				<td><center>".$row['pnr']."</center></td>
				<td><center>".$row['express']."</center></td>
				<td><center>".$row['from1']."</center></td>
				<td><center>".$row['to1']."</center></td>
				<td><center>".$row['date']."</center></td>
				<td><center>".$row['class']."</center></td>
				<td><center>".$row['adult']."</center></td>
				<td><center>".$row['children']."</center></td>
			</tr>
			</table>
			" ;
	
	
	
?>

	
</div>

<input type="button" onclick="printDiv('printarea')" value="print it"/>



</body>
</html>
