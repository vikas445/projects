<html>
<head>
	<title>About us</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
		<div class="main">
			<ul>
				<li><a href="home.php">Home</a></li>
				<li><a href="feedback.php">feedback</a></li>
				<li><a href="aboutus.php">About us</a></li>
			</ul>
		</div>
	<br><br><br><center><h1 style="color: white;top:25px;">About us</h1></center>
	<div style="padding:50px;"><p style="color: white;"> The Ministry of Railways set up CRIS as a Society in July 1986. We are headquartered in New Delhi, with Regional offices in Delhi, Kolkata, Mumbai, Chennai, and Secunderabad.<br><br>
 
Our current portfolio of projects covers the gamut of Indian Railways functions, such as passenger ticketing, freight operations, train dispatching and control, crew management, e-procurement, management of Railways fixed and moving assets, and production of rolling stock. Our information systems provide services in the remotest of locations, from Kargil to Kanyakumari, from Tawang to the Andaman Islands.<br><br>
 
Our human resources are our strength. Our 800 personnel include a pool of competent IT professionals, whose skillsets include system architecture, system analysis and design, and program development, complemented by an experienced group of serving and former Railway personnel with domain knowledge and system implementation skills. This unique combination gives us an unbeatable edge in the Railway and Government sector.<br><br>
 
Our collaborative model of working ensures the delivery of cost-effective, sustainable information systems. We have been successful in using cutting edge technologies in practical ways to ensure workable IT solutions for the Railways in many areas.<br><br>
 
We are currently developing systems to cover emerging needs of the Railways including the protection of Railway assets, energy management, management of the overhead electrification system, parcel management, employees health management, and a comprehensive financial management system.<br><br>
 
Other projects under execution include development of ticketing on mobile phones, linking tickets to Aadhaar, tracking of trains in real time through GPS, tracking of rolling stock using radio frequency identification, setting up a geo-spatial database for the Railways, and the setting up a state-of-the-art datacentre to house the Railways IT system. </p></div>
</body>
</html>