<?php
	$username=$_POST['username'];
	$password=$_POST['password'];
	session_start();
	$c=mysqli_connect("localhost","root","","login");
	$result=mysqli_query($c,"SELECT * FROM register where username='$username' and password='$password'");
	$row = mysqli_fetch_array($result);
	
	if($row['username']==$username && $row['password']==$password)
	{
		
		$_SESSION["loginuser"] = $username;
		echo "<script>alert('login sucessfull');</script>";
		echo "<script>location.href='welcome.php'</script>";
	}
	else if($username==admin && $password==admin)
	{
		
		$_SESSION["loginuser"] = admin;
		echo "<script>alert('Admin's login sucessfull');</script>";
		echo "<script>location.href='admin.php'</script>";
	}
	else
	{
		echo "<script>alert('username or password is incorrect');</script>";
		echo "<script>location.href='login.php'</script>";
	}

?>