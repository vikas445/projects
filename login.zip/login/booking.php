<html>
	<head>
		<title>welcome</title>
		<link rel="stylesheet" type="text/css" href="style.css">
		
		<script>
			function populate(s1,s2,s3)
			{
				var s1 = document.getElementById(s1);
				var s2 = document.getElementById(s2);
				var s3 = document.getElementById(s3);
				s2.innerHTML = ""; 	
				s3.innerHTML = ""; 	
				
				
				if(s1.value == "Vidharbha")
				{ 		
					var optionArray = ["|","Mumbai Cst|Mumbai Cst","Dadar|Dadar","Kalyan Junction|Kalyan Junction","Igatpuri|Igatpuri",
					"Chalisgaon Junction |Chalisgaon Junction ","Shegaon|Shegaon","Akola Junction |Akola Junction "];
				} 
				
				else if(s1.value == "Hatia")
				{ 		
					var optionArray = ["|"," Lokmanyatilak T| 	Lokmanyatilak T","Kalyan Junction| Kalyan Junction","Nasik Road | Nasik Road ","Bhusaval Junction|Bhusaval Junction",
					" Nagpur |Nagpur","Gondia Junction|Gondia Junction"," 	Hatia| 	Hatia"];
				}
				
				else if(s1.value == "Rajdhani")
				{ 		
					var optionArray = ["|","Bangalore  |Bangalore","Dadar|Dadar"," 	Sai P Nilayam| 	Sai P Nilayam","Raichur|Raichur",
					"Chalisgaon Junction |Chalisgaon Junction ","Shegaon|Shegaon","Akola Junction |Akola Junction "];
				}
				for(var option in optionArray)
				{ 	
					var pair = optionArray[option].split("|"); 	
  	 	 			var newOption = document.createElement("option"); 	
  	 	 			newOption.value = pair[0]; 	
  	 	 			newOption.innerHTML = pair[1]; 	
  	 	 			s2.options.add(newOption); 	
						
					
				} 
				for(var option in optionArray)
				{ 	
					var pair = optionArray[option].split("|"); 	
  	 	 			var newOption = document.createElement("option"); 	
  	 	 			newOption.value = pair[0]; 	
  	 	 			newOption.innerHTML = pair[1]; 	
  	 	 			s3.options.add(newOption); 	
				}
				
			}
  	 	 </script>
		
		
	</head>
	<body>
	<?php
		session_start();
		if(empty($_SESSION["loginuser"]))
		{
			header('Location:login.php');
		}
		?>
		<div class="title">
			<h1>Book your ticket</h1>
		</div>
		
		<div class="main">
			<ul>
				<li><a href="welcome.php">Main Page</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</div>
		
		<div class="login-page1">
		<div class ="form1">
		<form class="login-form1" action="booked_tickets.php" method="post">
			<table  border="1">
				<tr>
					<td><p style="margin-left:10px;">Name : </p></td>
					<td><input type="text" name="name" style="margin-left:40px;padding:20;top:10"></td>
				</tr>
				<tr>
					<td>
						<p style="margin-left:10px;">Express :</p>
					</td>
					<td width="500px">
						<select id="slct1" style="margin-left:40px;padding:10" name="slct1" onchange="populate(this.id,'slct2','slct3')"> 
							<option value=""></option> 
							<option value="Vidharbha">Vidharbha_Express</option> 
							<option value="Hatia">Hatia Express</option>
							<option value="Rajdhani">Rajdhani Express</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<p style="margin-left:10px;">From :</p>
					</td>
					<td width="500px">
						<select id="slct2" name="slct2" style="margin-left:40px;padding:10"></select>
					</td>
				</tr>
				<tr>
					<td>
						<p style="margin-left:10px;">To :</p>
					</td>
					<td>
						<select id="slct3" name="slct3" style="margin-left:40px;padding:10"></select>
					</td>
				</tr>
				<tr>
					<td><p style="margin-left:10px;">Date : </p></td>
					<td><input type="date" name="date" style="margin-left:40px;padding:20;top:10"></td>
				</tr>
				<tr>
					<td>
						<p style="margin-left:10px;">Class </p>
					</td>
					<td>
						<select style="margin-left:40px;padding:10;" name="class">
							<option>--- Choose class From Here ---</option>
							<option>A/C</option>
							<option>Sleeper</option>
							<option>Generel</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<p style="margin-left:10px;">Passenger </p>
					</td>
					<td>
						<label style="padding:40px">Adult:</label>
						<select name="adult" name="adult">
							<option>1</option>
							<option>2</option>
							<option>3</option>
							<option>4</option>
							<option>5</option>
						</select>
						<label style="padding:40px">Children:</label>
						<select name="children" name="children">
							<option>0</option>
							<option>1</option>
							<option>2</option>
							<option>3</option>
							<option>4</option>
							<option>5</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<p style="margin-left:10px;">Enter card number :</p>
					</td>
					<td>
						<input type="text" name="card_number" style="margin-left:40px;padding:20;top:10">
					</td>
				</tr>
				<tr>
					<td>
						<p style="margin-left:10px;">Enter cvv number :</p>
					</td>
					<td>
						<input type="text" name="cvv" style="margin-left:40px;padding:20;top:10">
					</td>
				</tr>
			</table>
			<button name="book">Submit</button>
			<input type = "reset" value = "reset">
			
		</form>
				</div>
				</div>
	</body>
</html>
