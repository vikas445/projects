
<html>
<head>
	<title>booked ticket</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<script type="text/javascript">
		function printDiv(divName) 
		{ 
			var printContents = document.getElementById(divName).innerHTML;
		 	var originalContents = document.body.innerHTML;
		  	document.body.innerHTML = printContents;
		   	window.print(); document.body.innerHTML = originalContents;
		}
	</script>
</head>
<body>


		<div class="main">
			<ul>
				<li><a href="fair.php">Fare Enquiry</a></li>
				<li><a href="booking.php">Book Ticket</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</div>

<h1 style="font-size:30px;color:white;top:30%;left:35%;position:absolute;">Your Ticket fair as follow</h1>
	<div id = "printarea">
<br><br><br><br><br><br>
	<br><br><br><center><img src="images/fair.png" height="1000" width="1500"></center>
</div>

<input type="button" onclick="printDiv('printarea')" value="print it"/>



</body>
</html>
