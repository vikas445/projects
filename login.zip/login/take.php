<!DOCTYPE html>
<html>
<head>
	<title>take</title>
</head>
<body>
	<form method="post" action="get.php">
		<input type="text" name="name"><br>
		<input type="submit" name="submit" value="submit">
	</form>
</body>
</html>
