<?php
		$firstname=$_POST['firstname'];
		$lastname=$_POST['lastname'];
		$username=$_POST['username'];
		$password=$_POST['password'];
		$password2=$_POST['password2'];
		$email=$_POST['email'];
		$address=$_POST['address'];
		$dob=$_POST['dob'];
		$mobno=$_POST['mobno'];
		$state=$_POST['state'];

	$db=mysqli_connect("localhost","root","","login");
	
	if(isset($_POST['register_btn']))
	{
		if($password==$password2)
		{
			
			$sql="insert into register values('$firstname','$lastname','$username','$password','$password2','$email','$address','$dob','$mobno','$state')";
			mysqli_query($db,$sql);
			echo "<script>alert('account created sucessfully');</script>";
			echo "<script>location.href='login.php'</script>";
		}
		else
		{
			echo "<script>alert('password do not match');</script>";
		}
	}
	else
		{
			echo "<script>alert('password do not match');</script>";
			echo "<script>location.href='register.php'</script>";
		}
	
?>