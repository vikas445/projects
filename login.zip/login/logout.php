<?php
session_start();
unset($_SESSION['loginuser']);
session_destroy();
echo "<script>alert('logout sucessfully');</script>";
header("Location: login.php");
?>