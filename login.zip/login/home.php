<html>
<head>
	<title>Home page</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<header>
		<div class="logo">
			<img src="images/logo.png" height="1">
		</div>
		<div class="main">
			<ul>
				<li><a href="home.php">Home</a></li>
			
				<li><a href="feedback.php">feedback</a></li>
				<li><a href="aboutus.php">About us</a></li>
				
			</ul>
		</div>
		<div class="title">
			<h1>WELCOME TO INDIAN RAILWAYS PASSENGER RESERVATION</h1>
		</div>
		
	</header>
	<div class="button">
			<a href="login.php" class="btn">login</a>
			<a href="register.php" class="btn">register</a>
	</div>
</body>
</html>