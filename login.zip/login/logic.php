<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script type="text/javascript">
		
	</script>
</head>
<body>
	<h2>choose your car</h2><br>
	Choose car make:
	<select id="slct1" name="slct1">
		<option value=""></option>
		<option value="Chevy">Chevy</option>
		<option value="Dodge">Dodge</option>
		<option value="Ford">Ford</option>
	</select>
	<br>
	Choosecar model:
	<select id="slct2" name="slct2"></select>
</body>
</html>