<html>
	<head>
		<title>login</title>
		<link rel="stylesheet" type="text/css" href="loginstyle.css">
	</head>
	<body>
			<ul>
				<li><a href="home.php">Home</a></li>
			
				<li><a href="#">About us </a></li>
				<li><a href="feedback.php">feedback</a></li>
			</ul>
				<h1 style="font-size:30px;color:white;top:15%;left:45%;position:absolute;">Login</h1>
				<br><br><div class="login-page">
					<div class="form">
						<form class="login-form" action="process1.php" method="post">
							<input type="text" placeholder="username" name="username" required/>
							<input type="password" placeholder="password" name="password" required/>
							<button name="login">login</button>
							<p class="message">Not registered? <a href="register.php">Create an account</a></p>
						</form>	
					</div>
				</div>
	</body>
</html>