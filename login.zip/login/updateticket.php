<html>
<head>
	<title>Update Ticket</title>

	<style>
			*{
			  margin: 5;
			  padding: 0;
			  font-family: Century Gothic;
			}

			header {
			   background-image: uri("violet.png"); 
			   height: 100vh;
			   background-size: cover;
			   background-position: center; 
			}

			ul{
			  float:right;
			  list-style-type: none:
			}

			ul li{
			  display: inline-block;
			}

			ul li a {
			  text-decoration: none;
			  color: #fff;
			  padding: 5px 20px;
			  border: 1px solid #fff;
			  transition: 0.6s ease;
			}

			.title {
			  position: absolute;
			  top: 20%;
			  left: 50%;
			  transform: translate(-50%,-50%);
			  color: #fff;
			}



			.button{
				padding-top: 5px;
			  position: absolute;
			  top: 50%;
			  left: 50%;
			  transform: translate(-50%,-50%);
			}

			.btn{
			  text-decoration: none;
			  color: #fff;
			  padding: 10px 90px;
			  border: 1px solid #fff;
			  transition: 0.6s ease;
			}

			 a:hover{
			  background-color: #fff;
			  color:#000; 
			}

			

			.logo img {
			float: left;
			width: 150px;
			height: auto;
			}

			.login-page {top:100px;
			  width: 600px;
			  padding: 10% 0 0;
			  margin: auto;
			}
			.form {top:100px;
			  position: relative;
			  z-index: 1;
			  background: #FFFFFF;
			  max-width: 360px;
			  margin: 0 auto 100px;
			  padding: 45px;
			  text-align: center;
			  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
			}
			.form input {
			  font-family: "Roboto", sans-serif;
			  outline: 0;
			  background: #f2f2f2;
			  width: 100%;
			  border: 0;
			  margin: 0 0 15px;
			  padding: 15px;
			  box-sizing: border-box;
			  font-size: 14px;
			}
			.form button {
				padding: 5px 35px;
			  font-family: "Roboto", sans-serif;
			  text-transform: uppercase;
			  outline: 0;
			  background: #3498db;
			  width: 50%;
			  border: 0;
			  padding: 15px;
			  color: #FFFFFF;
			  font-size: 14px;
			  -webkit-transition: all 0.3 ease;
			  transition: all 0.3 ease;
			  cursor: pointer;
			}
			.form button:hover,.form button:active,.form button:focus {
			  background: #2161bc;
			}
			.form .message {
			  margin: 15px 0 0;
			  color: #b3b3b3;
			  font-size: 12px;
			}
			.form .message a {
			  color: blue;
			  text-decoration: none;
			}
			.form .register-form {
			  display: none;
			}
			.container {
			  position: relative;
			  z-index: 1;
			  max-width: 300px;
			  margin: 0 auto;
			}
			.container:before, .container:after {
			  content: "";
			  display: block;
			  clear: both;
			}
			.container .info {
			  margin: 50px auto;
			  text-align: center;
			}
			.container .info h1 {
			  margin: 0 0 15px;
			  padding: 0;
			  font-size: 36px;
			  font-weight: 300;
			  color: #1a1a1a;
			}
			.container .info span {
			  color: #4d4d4d;
			  font-size: 12px;
			}
			.container .info span a {
			  color: #000000;
			  text-decoration: none;
			}
			.container .info span .fa {
			  color: #EF3B3A;
			}
			body {
			   background: #ffffff url("images/Indian-railway.jpg") no-repeat center;
				background-size: cover;
				height:100vh;
				background-attachment:fixed;
			  
			}
			</style>
</head>
<body>
	<div class="title">
			<h1>Update Ticket</h1>
		</div>
		
		<div class="main">
			<ul>
				<li><a href="logout.php">logout</a></li>
			</ul>
		</div>
		
		<div class="login-page">
		<div class ="form">
		<form class="login-form" action="updateprocess.php" method="post">
			<table>
				<tr>
					<td width="100px" align="left">Enter pnr no.</td>
					<td><input type="text" name="pnr" required>
				</tr>	
				<tr>
					<td align="left">Enter name</td>
					<td><input type="text" name="name" ></td><td><button name="name1"></button></td>
				</tr>
				<tr>
					<td align="left">Enter Express</td>
					<td><input type="text" name="express" =""></td><td><button name="express1"></button></td>
				</tr>
				<tr>
					<td align="left">from</td>
					<td><input type="text" name="from" =""></td><td><button name="from1"></button></td>
				</tr>
				<tr>
					<td align="left">to</td>
					<td><input type="text" name="to" =""></td><td><button name="to1"></button></td>
				</tr>
				<tr>
					<td align="left">date</td>
					<td><input type="text" name="date" =""></td><td><button name="date1"></button></td>
				</tr>
				<tr>
					<td align="left">class</td>
					<td><input type="text" name="class" =""></td><td><button name="class1"></button></td>
				</tr>
				
				<tr>
					<td align="left">Adult</td>
					<td><input type="text" name="adult" =""></td><td><button name="adult1"></button></td>
				</tr>
				<tr>
					<td align="left">children</td>
					<td><input type="text" name="children" =""></td><td><button name="children1"></button></td>
				</tr>
			</table>
			
			
		</form>
				</div>
				</div>
	
</body>
</html>