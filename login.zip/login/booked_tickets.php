<?php
	$name=$_POST['name'];
	$slct1=$_POST['slct1'];
	$slct2=$_POST['slct2'];
	$slct3=$_POST['slct3'];
	$date=$_POST['date'];
	$class=$_POST['class'];
	$adult=$_POST['adult'];
	$children=$_POST['children'];
	
	$db=mysqli_connect("localhost","root","","login");
	$card_number=$_POST['card_number'];
	$cvv=$_POST['cvv'];
	
	$c1=mysqli_connect("localhost","root","","login");
	$result1=mysqli_query($c1,"SELECT * FROM credit_card where card_number='$card_number' and cvv='$cvv'");
	$row1 = mysqli_fetch_array($result1);
	$result4=mysqli_query($c1,"SELECT * FROM vidharbha_express where station_name='$slct2'");
	$row4 = mysqli_fetch_array($result4);
	
	$result2=mysqli_query($c1,"SELECT * FROM vidharbha_express where station_name='$slct2'");
	$row2 = mysqli_fetch_array($result2);
	$result3=mysqli_query($c1,"update credit_card set balance=balance-250");
	if($row1['card_number']==$card_number && $row1['cvv']==$cvv)
	{
	if(isset($_POST['book']))
	{
		$sql="INSERT INTO `booked_passenger`(`name`,`express`, `from1`, `to1`, `date`, `class`, `adult`, `children`) VALUES
		('$name','$slct1','$slct2','$slct3','$date','$class','$adult','$children')";
		mysqli_query($db,$sql);
		echo "<script>alert('ticket booked sucessfully');</script>";
	}}
	else
		{
			echo "<script>alert('card not valid');</script>";
			echo "<script>location.href='welcome.php'</script>";
		}
?>


<html>
<head>
	<title>booked ticket</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<script type="text/javascript">
		function printDiv(divName)
		{ 
			var printContents = document.getElementById(divName).innerHTML;
		 	var originalContents = document.body.innerHTML;
		  	document.body.innerHTML = printContents;
		   	window.print(); document.body.innerHTML = originalContents;
		}
	</script>
</head>
<body>


		<div class="main">
			<ul>
				<li><a href="welcome.php">Main Page</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</div>

<h1 style="font-size:30px;color:white;top:30%;left:35%;position:absolute;">Your Ticket Details as follow</h1>
	<div id = "printarea">
<?php
	$name=$_POST['name'];
	$slct1=$_POST['slct1'];
	$slct2=$_POST['slct2'];
	$slct3=$_POST['slct3'];
	$date=$_POST['date'];
	$class=$_POST['class'];
	$adult=$_POST['adult'];
	$children=$_POST['children'];
	
	
	echo "<table height=300 width=400 border='1' bgcolor='#ffffcc' style='font-size:15px;color:black;padding:10px;top:50%;left:30%;position:absolute;''>
			<tr>
				<td>Name</td>
				<td>".$name."</td>
			</tr><tr>
				<td>Express</td>
				<td>".$slct1."</td>
			</tr>
			<tr>
				<td>Source Station</td>
				<td>".$slct2."</td>
			</tr>
			<tr>
				<td>Destination station</td>
				<td>".$slct3."</td>
			</tr>
			<tr>
				<td>Arrival Time</td>
				<td>".$row4['arrive']."</td>
			</tr>
			<tr>
				<td>Departure Time</td>
				<td>".$row4['departure']."</td>
			</tr>
			<tr>
				<td>Date</td>
				<td>".$date."</td>
			</tr>
			<tr>
				<td>Class</td>
				<td>".$class."</td>
			</tr>
			<tr>
				<td>No. of Adults</td>
				<td>".$adult."</td>
			</tr>
			<tr>
				<td>No. of Childrens</td>
				<td>".$children."</td>
			</tr>
			<tr>
				<td>Paid</td>
				<td>".$row2['distance']."</td>
			</tr>
			</table>
			" ;
	
	
	
?>

	
</div>

<input type="button" onclick="printDiv('printarea')" value="print it"/>



</body>
</html>
