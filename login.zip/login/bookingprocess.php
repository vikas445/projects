<?php
	$name=$_POST['name'];
	$slct1=$_POST['slct1'];
	$slct2=$_POST['slct2'];
	$slct3=$_POST['slct3'];
	$date=$_POST['date'];
	$class=$_POST['class'];
	$adult=$_POST['adult'];
	$children=$_POST['children'];
	
	$db=mysqli_connect("localhost","root","","login");
	
	if(isset($_POST['book']))
	{
		$sql="INSERT INTO `booked_passenger`(`name`,`express`, `from1`, `to1`, `date`, `class`, `adult`, `children`) VALUES
		('$name','$slct1','$slct2','$slct3','$date','$class','$adult','$children')";
		mysqli_query($db,$sql);
		echo "<script>alert('ticket booked sucessfully');</script>";
		echo "<script>location.href='booked_tickets.php'</script>";
	}
?>