<html>
<head>
	<title>booked ticket</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>


		<div class="main">
			<ul>
				<li><a href="welcome.php">Main Page</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</div>

<h1 style="font-size:30px;color:white;top:20%;left:35%;position:absolute;">Your Train Details as follow</h1><br>
<h1 style="font-size:25px;color:white;top:35%;left:38%;position:absolute;">Vidharbha Express</h1>
<table height=100 width=900 border='1' bgcolor='#ffffcc' style='font-size:15px;color:black;padding:10px;top:40%;left:10%;position:absolute;'''>
			<tr>
				<td><center>Station no</center></td>
				<td><center>Kilometer</center></td>
				<td><center>Station Name</center></td>
				<td><center>Arrival Time</center></td>
				<td><center>Destination Time</center></td>
			</tr>
			<tr>
				<td><center>1</center></td>
				<td><center>0</center></td>
				<td><center>Mumbai Cst</center></td>
				<td><center>12:00</center></td>
				<td><center>1:30</center></td>
			</tr>
			<tr>
				<td><center>2</center></td>
				<td><center>150</center></td>
				<td><center>Dadar</center></td>
				<td><center>2:30</center></td>
				<td><center>3:45</center></td>
			</tr>
			<tr>
				<td><center>3</center></td>
				<td><center>500</center></td>
				<td><center>Kalyan</center></td>
				<td><center>4:15</center></td>
				<td><center>5:23</center></td>
			</tr><tr>
				<td><center>4</center></td>
				<td><center>600</center></td>
				<td><center>Igatpuri</center></td>
				<td><center>6:33</center></td>
				<td><center>7:40</center></td>
			</tr>
			<tr>
				<td><center>5</center></td>
				<td><center>730</center></td>
				<td><center>Chalisgaon</center></td>
				<td><center>8:35</center></td>
				<td><center>8:40</center></td>
			</tr><tr>
				<td><center>6</center></td>
				<td><center>860</center></td>
				<td><center>Igatpuri</center></td>
				<td><center>9:35</center></td>
				<td><center>9:40</center></td>
			</tr><tr>
				<td><center>7</center></td>
				<td><center>987</center></td>
				<td><center>Shegaon</center></td>
				<td><center>10:00</center></td>
				<td><center>10:05</center></td>
			</tr><tr>
				<td><center>8</center></td>
				<td><center>1002</center></td>
				<td><center>Akola</center></td>
				<td><center>11:30</center></td>
				<td><center>11:45</center></td>
			</tr>
			</table>
			
			
			<center><h1 style="font-size:25px;color:white;top:100%;left:38%;position:absolute;">Hatia Express</h1></center>
<table height=100 width=900 border='1' bgcolor='#ffffcc' style='font-size:15px;color:black;padding:10px;top:110%;left:10%;position:absolute;'''>
			<tr>
				<td><center>Station no</center></td>
				<td><center>Kilometer</center></td>
				<td><center>Station Name</center></td>
				<td><center>Arrival Time</center></td>
				<td><center>Destination Time</center></td>
			</tr>
			<tr>
				<td><center>1</center></td>
				<td><center>0</center></td>
				<td><center>Lokmanyatilak</center></td>
				<td><center>02:00</center></td>
				<td><center>02:05</center></td>
			</tr>
			<tr>
				<td><center>2</center></td>
				<td><center>150</center></td>
				<td><center>Kalyan</center></td>
				<td><center>2:30</center></td>
				<td><center>3:45</center></td>
			</tr>
			<tr>
				<td><center>3</center></td>
				<td><center>500</center></td>
				<td><center>Nasik</center></td>
				<td><center>4:15</center></td>
				<td><center>5:23</center></td>
			</tr><tr>
				<td><center>4</center></td>
				<td><center>600</center></td>
				<td><center>Bhusaval</center></td>
				<td><center>6:33</center></td>
				<td><center>7:40</center></td>
			</tr>
			<tr>
				<td><center>5</center></td>
				<td><center>730</center></td>
				<td><center>Chalisgaon</center></td>
				<td><center>8:35</center></td>
				<td><center>8:40</center></td>
			</tr><tr>
				<td><center>6</center></td>
				<td><center>860</center></td>
				<td><center>Nagpur</center></td>
				<td><center>9:35</center></td>
				<td><center>9:40</center></td>
			</tr><tr>
				<td><center>7</center></td>
				<td><center>987</center></td>
				<td><center>Gondia</center></td>
				<td><center>10:00</center></td>
				<td><center>10:05</center></td>
			</tr><tr>
				<td><center>8</center></td>
				<td><center>1002</center></td>
				<td><center>Hatia</center></td>
				<td><center>11:30</center></td>
				<td><center>11:45</center></td>
			</tr>
			</table>
			
			
			<center><h1 style="font-size:25px;color:white;top:180%;left:38%;position:absolute;">Rajdhani Express</h1></center>
<table height=100 width=900 border='1' bgcolor='#ffffcc' style='font-size:15px;color:black;padding:10px;top:190%;left:10%;position:absolute;'''>
			<tr>
				<td><center>Station no</center></td>
				<td><center>Kilometer</center></td>
				<td><center>Station Name</center></td>
				<td><center>Arrival Time</center></td>
				<td><center>Destination Time</center></td>
			</tr>
			<tr>
				<td><center>1</center></td>
				<td><center>0</center></td>
				<td><center>Bangalore</center></td>
				<td><center>02:00</center></td>
				<td><center>02:05</center></td>
			</tr>
			<tr>
				<td><center>2</center></td>
				<td><center>150</center></td>
				<td><center>Dadar</center></td>
				<td><center>2:30</center></td>
				<td><center>3:45</center></td>
			</tr>
			<tr>
				<td><center>3</center></td>
				<td><center>500</center></td>
				<td><center>Sai P Nilayam</center></td>
				<td><center>4:15</center></td>
				<td><center>5:23</center></td>
			</tr><tr>
				<td><center>4</center></td>
				<td><center>600</center></td>
				<td><center>Raichur</center></td>
				<td><center>6:33</center></td>
				<td><center>7:40</center></td>
			</tr>
			<tr>
				<td><center>5</center></td>
				<td><center>730</center></td>
				<td><center>Chalisgaon</center></td>
				<td><center>8:35</center></td>
				<td><center>8:40</center></td>
			</tr><tr>
				<td><center>6</center></td>
				<td><center>860</center></td>
				<td><center>Nagpur</center></td>
				<td><center>9:35</center></td>
				<td><center>9:40</center></td>
			</tr><tr>
				<td><center>7</center></td>
				<td><center>987</center></td>
				<td><center>Gondia</center></td>
				<td><center>10:00</center></td>
				<td><center>10:05</center></td>
			</tr><tr>
				<td><center>8</center></td>
				<td><center>1002</center></td>
				<td><center>Akola</center></td>
				<td><center>11:30</center></td>
				<td><center>11:45</center></td>
			</tr>
			</table>
	<br><br><br><br>
</div>





</body>
</html>
