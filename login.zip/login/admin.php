
<html>
<head>
	<title>drop down</title>
	<style>
	body{
		background:url("images/Indian-railway.jpg") center no-repeat;
		background-size:cover;
		height:100vh;
	}
	
	.menudropdown{
		width:80%;
		height:100px;
		left:500px;
		align:center;
		


	}
	
	.menudropdown ul{
		padding:0px;
	}
	
	.menudropdown ul li{
		float:left;
		background-color:black;
		color:white;
		width:200px;
		height:50px;
		line-height:50px;
		font-size:20px;
		list-style:none;
		text-align:center;
		opacity:0.6;
	}
	
	.menudropdown ul li ul{
		display:none;
	}
	
	.menudropdown ul li:hover > ul{
		display:block;
	}
	
	.menudropdown ul li:hover{
		background-color:#32cd32;
	}
	
	ul li a{
			top:50px;
			color:white;
			display:block;
			text-decoration:none;
			font-size:20px
			text-align:50px;
			font-family:Century Gothic;
			font-weight:bold;

		}



		.main a:hover{
			background: #fff;
			color:black;
		}
		
		.main ul{
		  float:right;
		  list-style-type: none;
		}


		 .main ul li{
		  display: inline-block;
		}

		  .main ul li a {
		  text-decoration: none;
		  color: #fff;
		  padding: 5px 20px;
		  border: 1px solid #fff;
		  transition: 0.6s ease;
		}
		.title {
		  position: absolute;
		  top: 25%;
		  left: 50%;
		  transform: translate(-50%,-50%);
		  color: #fff;
		}
	</style>

</head>
<body><div class="main">
			<ul>
				
				<li><a href="welcome.php">Main page</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</div>
<br><br><br><center>
<div class="menudropdown">
	<ul>
		
				<li><a href="updateticket.php">update Ticket</a></li>
				<li><a href="booking.php">Reserve Ticket</a></li>
				<li><a href="cancel.php">Cancel Ticket</a></li>
				<li><a href="timetable.php">Train time table</a></li>
		
	</ul>
</div></center>
</div></center>
<div class="title">
			<h1>
			
					<?php
						session_start();
						if(empty($_SESSION["loginuser"]))
						{
							header('Location:login.php');
						}
		
						echo "welcome " . $_SESSION["loginuser"] . ".<br>";
					?>
			</h1>
		</div>
		
		<img src="images/train.jfif" height=300 width=500 style="top:40%;left:5%;position:absolute;">
		<div style="font-size:20px;color:white;top:40%;left:50%;position:absolute;">Our current portfolio of projects covers the gamut of Indian Railways functions, such as passenger ticketing, freight operations, train dispatching and control, crew management, e-procurement, management of Railways fixed and moving assets, and production of rolling stock. Our information systems provide services in the remotest of locations, from Kargil to Kanyakumari, from Tawang to the Andaman Islands.
		</div>
</body>
</html>