<?php
		$pnr=$_POST['pnr'];
		$name=$_POST['name'];
		$express=$_POST['express'];
		$from=$_POST['from'];
		$to=$_POST['to'];
		$date=$_POST['date'];
		$class=$_POST['class'];
		$adult=$_POST['adult'];
		$children=$_POST['children'];
		$db=mysqli_connect("localhost","root","","login");
	
	if(isset($_POST['name1']))
	{
		$sql="UPDATE `booked_passenger` SET `name`='$name' WHERE pnr='$pnr';";
		mysqli_query($db,$sql);
	}
	if(isset($_POST['express1']))
	{
		$sql="UPDATE `booked_passenger` SET express='$express' WHERE pnr='$pnr';";mysqli_query($db,$sql);
	}
	if(isset($_POST['from1']))
	{
		$sql="UPDATE `booked_passenger` SET from1='$from' WHERE pnr='$pnr';";mysqli_query($db,$sql);
	}
	if(isset($_POST['to1']))
	{
		$sql="UPDATE `booked_passenger` SET to1='$to' WHERE pnr='$pnr';";mysqli_query($db,$sql);
	}
	if(isset($_POST['date1']))
	{
		$sql="UPDATE `booked_passenger` SET date='$date' WHERE pnr='$pnr';";mysqli_query($db,$sql);
	}
	if(isset($_POST['class1']))
	{
		$sql="UPDATE `booked_passenger` SET class='$class' WHERE pnr='$pnr';";mysqli_query($db,$sql);
	}
	if(isset($_POST['adult1']))
	{
		$sql="UPDATE `booked_passenger` SET adult='$adult' WHERE pnr='$pnr';";mysqli_query($db,$sql);
	}
	if(isset($_POST['children1']))
	{
		$sql="UPDATE `booked_passenger` SET children='$children' WHERE pnr='$pnr';";mysqli_query($db,$sql);
	}
	
	
	
?>