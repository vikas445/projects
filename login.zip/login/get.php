
<?php
	$take=$_POST['name'];
	$db=mysqli_connect("localhost","root","","login");

	$sql="INSERT INTO demo VALUES('$take')";

		mysqli_query($db,$sql);
		echo "<script>alert('data inserted sucessfully');</script>";
?>