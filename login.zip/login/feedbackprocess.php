<?php


	$name=$_POST['name'];
	$phoneno=$_POST['phoneno'];
	$email=$_POST['email'];
	$message=$_POST['message'];


	$db=mysqli_connect("localhost","root","","login");

	if(isset($_POST['submit']))
	{		
			$sql="insert into feedback values('$name','$phoneno','$email','$message')";
			mysqli_query($db,$sql);
			echo "<script>alert('Feedback submited sucessfully');</script>";
			echo "<script>location.href='home.php'</script>";	
	}

?>